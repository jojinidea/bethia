#include <stdio.h> 
#include <string.h>
#include "set.h"
#include "BSTree.h"
#include "readData.h"

Tree createInvertedIndex (void);
Tree addInvertedIndex (Set textCollection, Tree invertedIndex, char *URL);

/*
int main (void) {
    Tree t = createInvertedIndex();
    freopen("invertedIndex.txt", "w", stdout);
    showTree(t);
    freeTree(t);

}
*/

Tree createInvertedIndex (void) {
    Set URLCollection = GetCollection();
    showSet(URLCollection);
    Set textCollection;
    Tree invertedIndex = newTree();
    Tree temp;

    int i = 0;
    
    for (i = 0; i < nElems(URLCollection) ; i++) {
        char *URL = leaveSet(URLCollection); 
        //printf("%s\n", URL);
        textCollection = returnSet(WANT_TEXT, TXT_NEEDED, URL);
        showSet(textCollection);
        temp = addInvertedIndex(textCollection, invertedIndex, URL);
        invertedIndex = temp;
      
    }
    freeTree(temp);
    disposeSet(URLCollection);
    disposeSet(textCollection);
    
    return invertedIndex;
    //showTree(invertedIndex);
    //Tree t = returnNode(invertedIndex, "mars");
    //printf("t->value is");
    //showNode(t);
    
    // for each URL in the URL collection, read it, if it doesn't exist in the BST, create a set of text with that URL name as a linked list thing
    

}

Tree addInvertedIndex (Set textCollection, Tree invertedIndex, char *URL) {
    Tree temp;
    int i = 0;
    char *key;
    Tree node; 
    Set URLSet;
    
    for (i = 0; i < nElems(textCollection); i++) {
        key = leaveSet(textCollection);
        if (TreeSearch(invertedIndex, key) == false) {
            temp = TreeInsert(invertedIndex, key, URL); 
            invertedIndex = temp;  
        } else {
            node = returnNode(invertedIndex, key);
            URLSet = returnURLSet(node);
            if (isElem(URLSet, URL) == FALSE) {
                insertInto(URLSet, URL);
            }
            showNode(node);
        }
    }
    freeTree(node);
    freeTree(temp);
    disposeSet(URLSet);

return invertedIndex; 

}



